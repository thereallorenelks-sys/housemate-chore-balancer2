# Housemate Chore Balancer

Deploy on Vercel:
1) Push to GitHub
2) Vercel → New Project → Import repo
3) Build: `npm run build`
4) Output: `dist`
